package model;

/**
 * This represents the location of an event.
 */
public enum Location {
  PHYSICAL,
  ONLINE;
}
