package controller;

import java.awt.event.ActionListener;

/**
 * Represents the Controller part of the Calendar.
 */
public interface IGUICalendarController extends ActionListener, CalendarController {

}
